#!/bin/bash
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"

if [ ! -d "venv" ]; then
    python3 -m venv venv
fi

./venv/bin/pip install --upgrade pip --quiet 2>/dev/null || true
./venv/bin/pip install --no-index --find-links=wheels -r requirements.txt --quiet 2>/dev/null || \
    ./venv/bin/pip install -r requirements.txt --quiet

if command -v pm2 &> /dev/null; then
    pm2 delete app-py 2>/dev/null || true
    pm2 start "$DIR/venv/bin/uvicorn" \
        --name "app-py" \
        --interpreter "none" \
        -- app:app --host 0.0.0.0 --port 3311 --workers 4
    pm2 save
else
    ./venv/bin/uvicorn app:app --host 0.0.0.0 --port 3311 --workers 4
fi
