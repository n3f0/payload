import gzip
import time
import asyncio
from typing import Optional
from contextlib import asynccontextmanager

import msgpack
import asyncpg
from fastapi import FastAPI, HTTPException
from fastapi.responses import Response
from pydantic import BaseModel, Field

_pool_cache: dict[str, asyncpg.Pool] = {}
_pool_locks: dict[str, asyncio.Lock] = {}
_pool_last_used: dict[str, float] = {}

POOL_MIN_SIZE = 2
POOL_MAX_SIZE = 10
POOL_MAX_IDLE_SEC = 300
POOL_COMMAND_TIMEOUT = 120
POOL_CLEANUP_INTERVAL = 60


@asynccontextmanager
async def lifespan(app: FastAPI):
    cleanup_task = asyncio.create_task(_pool_cleanup_loop())
    print(f"started | pool: {POOL_MIN_SIZE}-{POOL_MAX_SIZE} | timeout: {POOL_COMMAND_TIMEOUT}s")
    yield
    cleanup_task.cancel()
    for key, pool in _pool_cache.items():
        try:
            await pool.close()
        except Exception:
            pass


app = FastAPI(
    title="API",
    version="1.0.0",
    docs_url=None,
    redoc_url=None,
    openapi_url=None,
    lifespan=lifespan,
)


class QueryRequest(BaseModel):
    host: str
    port: int = 5432
    username: str
    password: str
    database: str
    schema_name: str = Field("public", alias="schema")
    query: str


class ErrorResponse(BaseModel):
    status: int
    error: str
    detail: Optional[str] = None


def _pool_key(host, port, username, database):
    return f"{host}:{port}:{username}:{database}"


async def _get_pool(host, port, username, password, database):
    key = _pool_key(host, port, username, database)

    if key in _pool_cache:
        pool = _pool_cache[key]
        try:
            async with pool.acquire(timeout=5) as conn:
                await conn.execute("SELECT 1")
            _pool_last_used[key] = time.time()
            return pool
        except Exception:
            try:
                await pool.close()
            except Exception:
                pass
            del _pool_cache[key]

    if key not in _pool_locks:
        _pool_locks[key] = asyncio.Lock()

    async with _pool_locks[key]:
        if key in _pool_cache:
            _pool_last_used[key] = time.time()
            return _pool_cache[key]

        pool = await asyncpg.create_pool(
            host=host, port=port, user=username, password=password,
            database=database, min_size=POOL_MIN_SIZE, max_size=POOL_MAX_SIZE,
            command_timeout=POOL_COMMAND_TIMEOUT, timeout=30,
        )

        _pool_cache[key] = pool
        _pool_last_used[key] = time.time()
        return pool


async def _pool_cleanup_loop():
    while True:
        try:
            await asyncio.sleep(POOL_CLEANUP_INTERVAL)
            now = time.time()
            expired = [k for k, t in _pool_last_used.items() if now - t > POOL_MAX_IDLE_SEC]
            for key in expired:
                if key in _pool_cache:
                    try:
                        await _pool_cache[key].close()
                    except Exception:
                        pass
                    del _pool_cache[key]
                    del _pool_last_used[key]
        except asyncio.CancelledError:
            break
        except Exception:
            pass


def _serialize_row(record):
    row = dict(record)
    for key, value in row.items():
        if isinstance(value, (bytes, bytearray)):
            row[key] = value.hex()
        elif hasattr(value, 'isoformat'):
            row[key] = value.isoformat()
        elif isinstance(value, set):
            row[key] = list(value)
    return row


def _pack_and_compress(data):
    packed = msgpack.packb(data, use_bin_type=True)
    return gzip.compress(packed, compresslevel=6)


@app.post("/query", response_class=Response)
async def execute_query(req: QueryRequest):
    start_time = time.time()

    try:
        pool = await _get_pool(req.host, req.port, req.username, req.password, req.database)
    except asyncpg.InvalidPasswordError:
        raise HTTPException(status_code=401, detail="auth failed")
    except asyncpg.InvalidCatalogNameError:
        raise HTTPException(status_code=400, detail=f"db not found: {req.database}")
    except OSError as e:
        raise HTTPException(status_code=503, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

    try:
        async with pool.acquire(timeout=30) as conn:
            if req.schema_name and req.schema_name != "public":
                await conn.execute(f"SET search_path TO {req.schema_name}, public")

            records = await conn.fetch(req.query)
            rows = [_serialize_row(r) for r in records]
            elapsed_ms = round((time.time() - start_time) * 1000, 2)

            result = {
                "status": 200,
                "rows": rows,
                "row_count": len(rows),
                "elapsed_ms": elapsed_ms,
            }

            compressed = _pack_and_compress(result)

            return Response(
                content=compressed,
                media_type="application/gzip",
                headers={
                    "X-Row-Count": str(len(rows)),
                    "X-Elapsed-Ms": str(elapsed_ms),
                    "Content-Encoding": "identity",
                },
            )

    except asyncpg.PostgresSyntaxError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except asyncpg.UndefinedTableError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except asyncpg.UndefinedColumnError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except asyncpg.InsufficientPrivilegeError as e:
        raise HTTPException(status_code=403, detail=str(e))
    except asyncio.TimeoutError:
        raise HTTPException(status_code=504, detail="timeout")
    except asyncpg.PostgresError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/health")
async def health():
    return {
        "status": "ok",
        "pools": {
            key: {
                "size": pool.get_size(),
                "free": pool.get_idle_size(),
                "used": pool.get_size() - pool.get_idle_size(),
            }
            for key, pool in _pool_cache.items()
        },
    }


@app.post("/query/json")
async def execute_query_json(req: QueryRequest):
    start_time = time.time()

    try:
        pool = await _get_pool(req.host, req.port, req.username, req.password, req.database)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

    try:
        async with pool.acquire(timeout=30) as conn:
            if req.schema_name and req.schema_name != "public":
                await conn.execute(f"SET search_path TO {req.schema_name}, public")

            records = await conn.fetch(req.query)
            rows = [_serialize_row(r) for r in records]
            elapsed_ms = round((time.time() - start_time) * 1000, 2)

            return {
                "status": 200,
                "rows": rows,
                "row_count": len(rows),
                "elapsed_ms": elapsed_ms,
            }

    except asyncpg.PostgresError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app:app", host="0.0.0.0", port=3311, workers=4)
